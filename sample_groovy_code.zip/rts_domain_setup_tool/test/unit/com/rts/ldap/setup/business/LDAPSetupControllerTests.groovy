package com.rts.ldap.setup.business

import static org.junit.Assert.*

import grails.test.mixin.*
import grails.test.mixin.support.*
import org.junit.*

import com.rts.ldap.connection.*
import com.rts.ldap.setup.business.*
import com.rts.ldap.setup.utils.RTSUtils

/**
 * See the API for {@link grails.test.mixin.support.GrailsUnitTestMixin} for usage instructions
 */
//@TestMixin(GrailsUnitTestMixin)
class LDAPSetupControllerTests {
	
	LDAP ldapConnection	
	
    
	String domainName = "alex001.sks.com"
	String groupDn = "ou=Apps"
	void setUp() {
        // Setup logic here
    }

    void tearDown() {
        // Tear down logic here
    }
	
	@Ignore
    void testSomething() {
        fail "Implement me"
    }
	
	@Ignore
	void createRootEntry(){
		ldapConnection = LDAPConnector.getInstance().getConnection()
		LDAPSetupController.getInstance().createOrganizationalUnit(domainName,domainName, ldapConnection)
		RTSUtils.getInstance().finalizeLDAPConnection()
	}
	
	@Ignore
	void createGroupOfNames(){
		ldapConnection = LDAPConnector.getInstance().getConnection()
		LDAPSetupController.getInstance().createGenericGroupOfNames(groupDn, domainName, ldapConnection)
		RTSUtils.getInstance().finalizeLDAPConnection()
	}
	
	@Ignore
	void createAppsStructure(){
		ldapConnection = LDAPConnector.getInstance().getConnection()
		LDAPSetupController.getInstance().createAppsStructure(domainName, ldapConnection)
		RTSUtils.getInstance().finalizeLDAPConnection()
	}
	
	@Ignore
	void createCmsFrameworkOrganizationalUnit(){
		ldapConnection = LDAPConnector.getInstance().getConnection()
		LDAPSetupController.getInstance().createCmsFrameworkOrganizationalUnit(domainName, ldapConnection)
		RTSUtils.getInstance().finalizeLDAPConnection()
	}
	
	@Test
	void createDomain(){
		ldapConnection = LDAPConnector.getInstance().getConnection()
		LDAPSetupController.getInstance().createDomain(domainName, ldapConnection)
		RTSUtils.getInstance().finalizeLDAPConnection()
		
	}
	@Ignore
	void createFileSystemOrganizationalUnit(){
		
		createFileSystemOrganizationalUnit
	}
}
