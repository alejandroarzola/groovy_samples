package com.rts.ldap.setup.rest.login

class LoginController {

    def index() { }
	
	def validateUser(){
		String userName
		String userPassword
		if(request.method == "POST"){
			if(params.txtUserName){
				if( params.txtPassword){
					userName = params.txtUserName
					userPassword = params.txtPassword
					if((userName == "admin@sks.com") && (userPassword == "rtssks2011")){
						session["isLoggedIn"] = "true"
						redirect(mapping: 'createDomainView')
						
					}else{
						render 'Wrong user name or password'
					}
				}else{
				render "Missing password"
				}
			}else{
				render "Missing user name"
			}
		}else{
			render "Real Time Solutions"
		}
	}
	
}
