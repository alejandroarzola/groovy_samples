package com.rts.ldap.setup.rest.domain

import com.rts.ldap.connection.*
import com.rts.ldap.setup.business.*
import com.rts.ldap.setup.utils.*

class DomainController {

	LDAP ldapConnection
	
    def index() { }
	
	def createDomain(){
		boolean result = false
		boolean domainExists = false
		if(request.method == "POST"){
			if(session["isLoggedIn"] == "true"){
				if(params.txtDomain){
					String domainName = params.txtDomain
					ldapConnection = LDAPConnector.getInstance().getConnection()
					domainExists = LDAPSetupController.getInstance().domainExists(domainName, ldapConnection)
					if(domainExists == false){
						result = LDAPSetupController.getInstance().createDomain(domainName, ldapConnection)
						if(result == true){
							render "Domain created successfully !! :D"
						}else{
							render "Domain not created !! D:"
						}
					}else{
						render "Domain already exists !! D:"
					}
					
					RTSUtils.getInstance().finalizeLDAPConnection()
				}else{
					render "Domain name not supplied"
				}
			}else{
				render "User was not logged in"
			}
		}else{
			render "Real Time Solutions"
		}
		
	}
	//using an action submit button, the action must be within the same controller
	def logout(){
		session.invalidate()
		redirect(mapping: 'loginView')
	}
}
