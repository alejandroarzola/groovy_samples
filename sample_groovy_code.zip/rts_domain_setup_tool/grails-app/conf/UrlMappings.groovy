class UrlMappings {

	static mappings = {
		"/$controller/$action?/$id?"{
			constraints {
				// apply constraints here
			}
		}

		"/"(view:"/index")
		"500"(view:'/error')
		name createDomainView: "/domain/create-domain"(view: "/domain/create_domain")
		name createDomainController: "/domain/create-domain-response"(controller: "domain",action:[POST: 'createDomain'])
		
		name loginView: "/login/"(view:"/login/login_start")
		name loginController: "/login/do-login/"(controller: "login", action:[POST: 'validateUser'])
		
		name logoutView: "/logout/"(controller: "login", action:'logout')

	}
}
