package com.rts.ldap.connection
//Deprecated
import javax.naming.NamingException;
import javax.naming.ldap.LdapContext;

/**
 * DEPRECATED
 * 
 * @author Everardo Dominguez Azdar
 *
 */
public interface WithContext <T> {

	T perform(LdapContext ctx) throws NamingException
	
}
