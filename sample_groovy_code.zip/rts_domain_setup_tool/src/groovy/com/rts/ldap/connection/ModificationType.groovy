package com.rts.ldap.connection
//internal use
import javax.naming.directory.DirContext;

/**
 * @author Everardo Dominguez Azdar
 *
 */
enum ModificationType {
	
	ADD(DirContext.ADD_ATTRIBUTE), DELETE(DirContext.REMOVE_ATTRIBUTE), REPLACE(DirContext.REPLACE_ATTRIBUTE);
	
	private int jndiValue;

	private ModificationType( int jndiValue )
	{
		this.jndiValue = jndiValue;
	}

	public int getJndiValue()
	{
		return jndiValue;
	}
}
