package com.rts.ldap.connection


/**
 * 
 * @author alex
 *
 */
class LDAPConnector {
	
	private static LDAPConnector _ldapConnector
	private static LDAP ldapConnection
	/**
	 * This url need to be configured in host file in the OS
	 */
	private static final String productionIP = "authentication.sks.com"
	private static final String ldapPort = "389"
	private static final String connectionString = 'ldap://'+ productionIP +':' + ldapPort+'/'

	/**
	 * Singleton implementation
	 * */
	private LDAPConnector(){
		ldapConnection = LDAP.newInstance(connectionString,"cn=Manager,dc=realtimesites,dc=com","rt5sk52oO1!")
	}
	
	private LDAPConnector(String ldapDomainName){
		String _connectionString = "ldap://${ldapDomainName}:389/"
		ldapConnection = LDAP.newInstance(_connectionString,"cn=Manager,dc=realtimesites,dc=com","rt5sk52oO1!")
	}
	
	private LDAPConnector(String ldapDomainName, String ldapPortNumber){
		String _connectionString = "ldap://${ldapDomainName}:${ldapPortNumber}/"
		ldapConnection = LDAP.newInstance(_connectionString,"cn=Manager,dc=realtimesites,dc=com","rt5sk52oO1!")
	}
	
	private LDAPConnector(String ldapDomainName, String ldapPortNumber, String ldapBindUserName, String ldapBindUserPasword){
		String _connectionString = "ldap://${ldapDomainName}:${ldapPortNumber}/"
		ldapConnection = LDAP.newInstance(_connectionString,ldapBindUserName,ldapBindUserPassword)
	}
	
	
	public static LDAPConnector getInstance(){
		if(_ldapConnector == null){
			_ldapConnector = new LDAPConnector()
		}
		return _ldapConnector 
	}
	
	public static LDAPConnector getInstance(String ldapDomainName){
		if(_ldapConnector == null){
			_ldapConnector = new LDAPConnector(ldapDomainName)
		}
		return _ldapConnector
	}
	
	public static LDAPConnector getInstance(String ldapDomainName, String ldapPortNumber){
		if(_ldapConnector == null){
			_ldapConnector = new LDAPConnector(ldapDomainName, ldapPortNumber)
		}
		return _ldapConnector
	}
		
	public static LDAPConnector getInstance(String ldapDomainName, String ldapPortNumber, String ldapBindUserName, String ldapBindUserPassword){
		if(_ldapConnector == null){
			_ldapConnector = new LDAPConnector(ldapDomainName, ldapPortNumber, ldapBindUserName, ldapBindUserPassword)
		}
		return _ldapConnector
	}
	
	/**
	 * 
	 * @return LDAP connection
	 */
	public LDAP getConnection(){
		return ldapConnection
	}
	
	LDAP newInstance(){
		return LDAP.newInstance(connectionString,"cn=Manager,dc=realtimesites,dc=com","rt5sk52oO1!")
	}
}

