package com.rts.ldap.connection

import javax.naming.directory.SearchControls;

/**
 * Enumeration for the search scope options. To be used in LDAP search operations.
 * 
 * @author Everardo Dominguez Azdar
 *
 */
enum SearchScope {
	BASE(SearchControls.OBJECT_SCOPE), ONE(SearchControls.ONELEVEL_SCOPE), SUB(SearchControls.SUBTREE_SCOPE)
	
	private int jndiValue


	private SearchScope( int jndiValue )
	{
		this.jndiValue = jndiValue
	}


	public int getJndiValue()
	{
		return jndiValue
	}
}
