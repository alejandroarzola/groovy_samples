package com.rts.ldap.connection
/**
 * ALWAYS Close a context created using this class.
 */
import javax.naming.Context;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;

/**
 * @author Everardo Dominguez Azdar
 *
 */
class ContextManagement {
	private static _ctxMgmnt
	public url
	public bindUser
	public bindPassword

	/**
	 * Singleton Implementation
	 */
	public static getInstance(String url,String bindUser,String bindPassword){
		if(_ctxMgmnt == null){
			_ctxMgmnt = new ContextManagement()
			_ctxMgmnt.url = url
			_ctxMgmnt.bindUser = bindUser
			_ctxMgmnt.bindPassword = bindPassword
		}
		return _ctxMgmnt
	}
	
	private ContextManagement(){
		
	}
	/**
	 * Context Creation for manipulation of LDAP information
	 * 
	 * @param url
	 * @param bindUser
	 * @param bindPassword
	 * @return
	 */
	public LdapContext createContext(){
		LdapContext context = null;
		// Set up environment for creating initial context
		Hashtable<String, String> env = new Hashtable<String, String>(11)
		env.put(Context.INITIAL_CONTEXT_FACTORY,"com.sun.jndi.ldap.LdapCtxFactory")
		//String providerUrl = "ldaps://" + m_serverAddress + ":" + m_serverPort				+ "/";
		env.put(Context.PROVIDER_URL, url)
		//env.put(Context.SECURITY_AUTHENTICATION, "GSSAPI");
		env.put(Context.OBJECT_FACTORIES, "org.apache.directory.groovyldap.jndi.DirContextToMapObjectFactory" )
		env.put(Context.SECURITY_PRINCIPAL, bindUser)
		env.put(Context.SECURITY_CREDENTIALS, bindPassword)
		//env.put(Context.SECURITY_PROTOCOL, "ssl");
		context = new InitialLdapContext(env, null)
		return context
	}
	
}
