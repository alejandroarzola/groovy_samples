package com.rts.ldap.connection.jndi
/**
 * Not used
 * 
 */
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.naming.Context;
import javax.naming.Name;
import javax.naming.NamingEnumeration;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.spi.DirObjectFactory;

/**
 *  A JNDI ObjectFactory, which transforms a DirContext object into a map which contains its attributes.
 * 
 * @author Everardo Dominguez Azdar
 *
 */
class DirContextToMapObjectFactory implements DirObjectFactory {
	
	public Object getObjectInstance( Object obj, Name name, Context ctx, Hashtable env, Attributes attrs )
	throws Exception
	{
	
		if ( obj instanceof DirContext )
		{
	
			DirContext dctx = ( DirContext ) obj;
	
			// add distinguished name (DN) of entry to the map
			Map<String, Object> map = new TreeMap<String, Object>(String.CASE_INSENSITIVE_ORDER);
			map.put( "dn", dctx.getNameInNamespace() );
	
			NamingEnumeration<? extends Attribute> e = attrs.getAll();
			while ( e.hasMore() )
			{
				Attribute attribute = e.next();
				String attrName = attribute.getID(); //.toLowerCase();
	
				if ( attribute.size() == 1 )
				{
					map.put( attrName, attribute.get() );
				}
				else
				{
					List<Object> l = new ArrayList<Object>();
					for ( int i = 0; i < attribute.size(); ++i )
					{
						l.add( attribute.get( i ) );
					}
					map.put( attrName, l );
				}
			}
			return map;
		}
		else
		{
			return null;
		}
	}
	
	public Object getObjectInstance( Object obj, Name name, Context ctx, Hashtable env )
	{
		return null;
	}
}
