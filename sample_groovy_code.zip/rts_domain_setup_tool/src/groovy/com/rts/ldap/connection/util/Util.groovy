package com.rts.ldap.connection.util

import java.util.Collection;

import javax.naming.directory.Attribute;
import javax.naming.directory.BasicAttribute;

/**
 * Utility Methods for connection
 * 
 * @author Everardo Dominguez Azdar
 *
 */
class Util {
	private Util()
	{
	}


	/**
	 * Creates an attribute from the given parameters. If value is a collection,
	 * a multi-valued attribute will be created.
	 *
	 * @param name
	 *            Name of the attribute
	 * @param value
	 * @return a JNDI attribute object
	 * This classed is used for:
	 */
	public static Attribute createAttribute( String name, Object value )
	{
		Attribute attr = new BasicAttribute( name );
		if ( value instanceof Collection )
		{
			Collection<?> values = ( Collection<?> ) value;
			for ( Object val : values )
			{
				attr.add( val );
			}
		}
		else
		{
			attr.add( value );
		}
		return attr;
	}
}
