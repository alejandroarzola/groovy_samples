package com.rts.ldap.setup.utils
import java.security.MessageDigest
import java.util.ArrayList

/*import org.apache.directory.groovyldap.LDAP
import org.apache.directory.groovyldap.SearchScope*/

import com.rts.ldap.connection.LDAP
import com.rts.ldap.connection.SearchScope
import com.rts.ldap.setup.model.*


import com.rts.security.ldap.model.*

import com.rts.ldap.setup.utils.RTSUtils
import com.thoughtworks.xstream.core.util.Base64Encoder


import javax.naming.directory.SearchControls
import javax.naming.directory.SearchResult
import javax.naming.directory.Attributes
import javax.naming.directory.BasicAttributes
import javax.naming.directory.BasicAttribute
import javax.naming.directory.Attribute
import javax.naming.NamingEnumeration
import com.sun.jndi.ldap.LdapCtx


import org.springframework.ldap.core.ContextMapper;
import org.springframework.ldap.core.DirContextAdapter;


class LDAPUtils {
	private static String MAIN_DN = LDAPCommonDistinguishedNames.MAIN_DN
	private static LDAPUtils _ldapUtils
	
	private LDAPUtils(){}
	
	public static LDAPUtils getInstance(){
		if(_ldapUtils == null){
			_ldapUtils = new LDAPUtils()
		}
		return _ldapUtils
	}
	
	
	/**
	 * @author Paco Zarate (Pacisimo)
	 * @param parentDn
	 * @param ldapConnection
	 */
	static Boolean deleteTree(String parentDn,LDAP ldapConnection){
		Boolean result = false
		try{
			
			if((parentDn) && (ldapConnection.exists(parentDn))){
				def ldapContextSearch = ldapConnection.search("(${LDAPObjectClasses.OBJECT_CLASS_GROUP_OF_NAMES})",parentDn,SearchScope.ONE)
				if(ldapContextSearch!=null && ldapContextSearch != '' && ldapContextSearch != []){
					for (LdapCtx ldapContextResult in ldapContextSearch){
						def ldapAttributes = LDAPUtils.getInstance().getLdapContextAttributes(ldapContextResult)
						result = deleteTree(ldapAttributes.dn, ldapConnection)
					}
				}
				
				ldapConnection.delete (parentDn)
				result = true
			}
		}catch(Exception ex){
			printException("deleteTree",ex)
		}
		
		return result 
	}
	/**
	 * @param distinguishedName
	 * @param ldapSearchParameter
	 * @param parameterToRemove
	 * @return
	 */
	String getParentDistinguishedName(String distinguishedName,String ldapSearchParameter,String parameterToRemove){
		String getParentDistinguishedName = ""
		
		getParentDistinguishedName = distinguishedName.replace("${ldapSearchParameter}=${parameterToRemove},","")
		
		return getParentDistinguishedName
	}
	/**
	 * Verify if the object class you check is inside of the entry of LDAP
	 * 
	 * @param ldapObject
	 * @param ldapObjectClassToCheck
	 * @return
	 */
	boolean ldapObjectHasObjectClass(List<String> ldapObjectClassesList, String ldapObjectClassToCheck){
		boolean hasObjectClass = false
		for(entry in ldapObjectClassesList){
			if(entry == ldapObjectClassToCheck){
				hasObjectClass = true
				break
			}
		}
		return hasObjectClass
		
	}
	
	
	
	/**
	 * Verify if the group entry from LDAP has a reference group
	 * 
	 * @param ldapObject
	 * @param ldapReferencedGroupToCheck
	 * @return
	 */
	boolean ldapHasReferencedGroup(def ldapObject, String ldapReferencedGroupToCheck){
		boolean hasReferencedGroup =false
		for(entry in ldapObject){
			if(entry.referenceGroup == ldapReferencedGroupToCheck){
				hasReferencedGroup=true
				break
				}
			
			}
		return hasReferencedGroup
		}
	/**
	 * VErify if the group entry form LDAP has a reference propagated
	 * 
	 * @param ldapObject
	 * @param ldapReferencedGroupToCheck
	 * @return
	 */
	boolean ldapHasPropagatedReferencedGroup(def ldapObject, String ldapReferencedGroupToCheck){
		boolean hasReferencedGroup =false
		for(entry in ldapObject){
			if(entry.referenceGroupPropagated == ldapReferencedGroupToCheck){
				hasReferencedGroup=true
				break
				}
			
			}
		return hasReferencedGroup
		}
	
	/**
	 * 
	 * @param ldapEntry
	 * @return ldapAttributes - HashMap containing all the attributes in the ldapContext
	 */
	def transformLDAPEntryToOrgChartGroup(LdapCtx ldapEntry){
		def ldapAttributes
		try{
			ldapAttributes =  getLdapContextAttributes(ldapEntry)
		}catch(Exception ex){
			println "Exception in transformLDAPEntryToOrgChartGroup: ${ex.getMessage()}"
			ex.printStackTrace()
		}
		ldapAttributes
	}
	
	
	/**
	 * This check if references of the person are equal
	 * @param member1
	 * @param member2
	 * @return
	 */
	Boolean isEqualPersonDn(String member1, String member2){
		if (member1 == member2)
			return true
		String member1Extended = "${member1},${MAIN_DN}"
		String member2Extended = "${member2},${MAIN_DN}"
		if (member1Extended == member2)
			return true
		if (member1 == member2Extended)
			return true
		if (member1Extended == member2Extended)
			return true
		return false
	}
	
	
	def getLdapContextAttributes(LdapCtx ldapContext){
		Attributes ldapContextAttributes
		
		//HashMap<String, String> ldapAttributes  = new HashMap()
		def ldapAttributes = [:]
		String filter = "(objectClass=*)"
		SearchControls searchControls = new SearchControls()
		searchControls.setSearchScope(SearchControls.OBJECT_SCOPE)
		NamingEnumeration ldapSearchResults
		SearchResult searchResult
		
		ldapSearchResults = ldapContext.search("", filter,searchControls)
		if(ldapSearchResults.hasMore()){
			searchResult = ldapSearchResults.next()
			//println searchResult.getAttributes()
			ldapContextAttributes = searchResult.getAttributes()
			
		}
		
		NamingEnumeration<Attributes> ldapBasicAttributes = ldapContextAttributes.getAll()
		if(ldapBasicAttributes != null){
			while(ldapBasicAttributes.hasMore()){
				Attribute attribute = ldapBasicAttributes.next()
				
				//println "${attribute.getID()}: ${attribute.get()} "
				//def genericAttribute = ["${attribute.getID()}" : "${attribute.get()}"]
				ldapAttributes.putAt(attribute.getID(), attribute.get())
				//ldapAttributes["${attribute.getID()}"] =  attribute.get()
			}
			ldapAttributes["dn"] = ldapContext.currentDN
			
		}
		//println ldapAttributes
		
		
		Attributes memberAttributesList = searchResult.getAttributes()
		Attribute memberAttribute
		NamingEnumeration<String> members
		String memberDn
		if(memberAttributesList.get("member") != null){
			memberAttribute = memberAttributesList.get("member")
			if(memberAttribute != null){
				List<String> membersList = new ArrayList<String>()
				members = (NamingEnumeration<String>)memberAttribute.getAll()
				while(members.hasMoreElements()){
					memberDn = members.nextElement()
					if(!memberDn.contains("uid=unknown")){
						membersList.add(memberDn)
					}
					
				}
				ldapAttributes.putAt("member", membersList)
			}
		}
		
		ldapAttributes
	}
	
	List<String> getObjectClassesForLdapAttributes(LdapCtx ldapContext){
		List<String> objectClassesStrings
		def ldapObjectClassAttributes = [:]
		SearchControls searchControls = new SearchControls()
		String filter = "(objectClass=*)"
		Attributes ldapContextAttributes
		NamingEnumeration ldapSearchResults
		SearchResult searchResult
		Attribute objectClassAttribute
		NamingEnumeration<String> objectClasses
		
		searchControls.setSearchScope(SearchControls.OBJECT_SCOPE)
		ldapSearchResults = ldapContext.search("", filter,searchControls)
		if(ldapSearchResults.hasMore()){
			searchResult = ldapSearchResults.next()
			ldapContextAttributes = searchResult.getAttributes()
		}
		
		Attributes objectClassAttributesList = searchResult.getAttributes()
		
		
		
		if(objectClassAttributesList.get("objectClass") != null){
			objectClassAttribute = objectClassAttributesList.get("objectClass")
			if(objectClassAttribute != null){
				objectClassesStrings = new ArrayList<String>()
				objectClasses = (NamingEnumeration<String>)objectClassAttribute.getAll()
				while(objectClasses.hasMoreElements()){
					objectClassesStrings.add(objectClasses.nextElement())
				}
			}
		}
		
		objectClassesStrings
	}
	
	/**
	 * Converts a string representation of the ldap password byte array to its corresponding ldap hash
	 * @param byteArrayAsString
	 * @return ldapHash
	 */
	
	String convertLdapByteArrayPasswordToHash(String byteArrayAsString){
		String ldapHash = ""
		if(byteArrayAsString != "null"){
			String trimmedByteArrayAsString = byteArrayAsString.replace("[","").replace("]","").replace(" ","")
			String[] individualCharacters = trimmedByteArrayAsString.split(",")
			for(String character in individualCharacters){
				int characterNumber = Integer.parseInt(character)
				ldapHash+= (char)characterNumber
			}
		}
		ldapHash
	}
	
	void printException(String methodName, Exception ex){
		println "Exception in ${this.class}.${methodName}: ${ex.getMessage()}"
		ex.printStackTrace()
	}
	
}
