package com.rts.ldap.setup.utils
/**
 * 
 * @author Paco / Alex
 *
 */
import static java.util.UUID.randomUUID
import java.security.MessageDigest
class RTSUtils {
	
	private static RTSUtils _rtsUtils
	private RTSUtils(){}
	
	
	public static RTSUtils getInstance(){
		if(_rtsUtils == null){
			_rtsUtils = new RTSUtils()
		}
		
		return _rtsUtils
	}
	
	public static String generateGUID(){
		String guid = randomUUID().toString()
		guid = guid.replace ('-', '')
		
		return guid
	}
	
	public boolean validateLDAPPassword(def ldapPassword, String userEncryptedPassword){
		boolean isValid = true
		if(ldapPassword.size() == userEncryptedPassword.size()){
			for(int i =0; i< ldapPassword.size(); i++){
				if(ldapPassword[i] != userEncryptedPassword[i]){
					isValid = false
					break
				}
			}
		}	
		
		return isValid
	}
	
	public String convertLDAPPasswordToString(def ldapPassword){
		String convertedPassword = ""
		for(int ascii in ldapPassword){
			convertedPassword += (char)ascii
		}
		
		return convertedPassword
	}
	
	/**
	 * MD5 Password encryption
	 *
	 * @param password
	 * @return
	 */
	static String encryptMD5Password(String password){
		String _result = ""
		try
		{
			MessageDigest digest = MessageDigest.getInstance("MD5")
			digest.update(password.getBytes())
			def base64 =digest.digest().encodeBase64().toString()
			_result = base64
		}
		catch (Exception e) {
			//log.debug("There a problem encrypting the password");
			println e.getMessage()
			e.printStackTrace()
			throw new Exception("There was a problem encrypting the password", e)
		}

		return "{MD5}" + _result

	}
	/**
	 * SHA1 Password encryption
	 *
	 * @param password
	 * @return
	 */
	static String encryptSHA1Password(String password){
		String _result = ""

		try
		{
			MessageDigest digest = MessageDigest.getInstance("SHA1")
			digest.update(password.getBytes())
			def base64 =digest.digest().encodeBase64().toString()
			_result = base64
		}
		catch (Exception e) {
			//log.debug("There a problem encrypting the password");
			throw new Exception("There was a problem encrypting the password", e)
		}

		return "{SHA1}" + _result

	}
	/**
	 * SHA Password encryption
	 *
	 * @param password
	 * @return
	 */
	static String encryptPasswordSHA(String password){
		String _result = ""

		try
		{
			MessageDigest digest = MessageDigest.getInstance("SHA")
			digest.update(password.getBytes())
			def base64 =digest.digest().encodeBase64().toString()
			_result = base64
		}
		catch (Exception e) {
			//log.debug("There a problem encrypting the password");
			throw new Exception("There was a problem encrypting the password", e)
		}

		return "{SHA}" + _result

	}
	
	public void finalizeLDAPConnection(){
		try{
			Runtime.getRuntime().gc()
			Runtime.getRuntime().runFinalization()
		}catch(Exception ex){
			println "Error when trying to finalize LDAP connection"
		}
	}
	
}
