package com.rts.ldap.setup.model

class LDAPBooleanValues {
	public static final BOOLEAN_VALUE_TRUE = "TRUE"
	public static final BOOLEAN_VALUE_FALSE = "FALSE"
}
