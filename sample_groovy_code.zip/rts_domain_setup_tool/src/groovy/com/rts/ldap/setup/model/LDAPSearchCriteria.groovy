package com.rts.ldap.setup.model

class LDAPSearchCriteria {
	static final String SEARCH_CRITERIA_BY_GROUP_GUID ="byGroupGuid"
	//userName == mail
	static final String SEARCH_CRITERIA_BY_ORGCHART_NAME ="byUserName"
	
	static final String SEARCH_CRITERIA_BY_USER_GUID ="byUserGuid"
	
	static final String SEARCH_CRITERIA_BY_GROUP_GUID_OU ="byGroupGuidOU"
}
