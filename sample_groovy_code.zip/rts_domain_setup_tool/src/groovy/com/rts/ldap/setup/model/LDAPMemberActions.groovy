package com.rts.ldap.setup.model
/**
 * @author alex
 */
class LDAPMemberActions {
	static final String MEMBER_ACTION_ADD = "ADD"
	static final String MEMBER_ACTION_DELETE = "DELETE"
	static final String MEMBER_ACTION_REPLACE = "REPLACE"
}
