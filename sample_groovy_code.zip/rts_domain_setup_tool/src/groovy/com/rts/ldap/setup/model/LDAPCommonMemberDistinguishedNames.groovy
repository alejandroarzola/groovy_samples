package com.rts.ldap.setup.model

class LDAPCommonMemberDistinguishedNames {
	
	public static String MEMBER_RTS_ADMIN = "uid=rtsadmin,${LDAPCommonDistinguishedNames.PEOPLE_RDN},ou=domainName,${LDAPCommonDistinguishedNames.DOMAINS_DN}"
	public static String MEMBER_ADMIN2 = "uid=admin2,${LDAPCommonDistinguishedNames.PEOPLE_RDN},ou=domainName,${LDAPCommonDistinguishedNames.DOMAINS_DN}"
	public static String MEMBER_UNKNOWN = "${LDAPCommonDistinguishedNames.DEFAULTUSER_RDN},${LDAPCommonDistinguishedNames.PEOPLE_RDN},ou=domainName,${LDAPCommonDistinguishedNames.DOMAINS_RDN}"
}
