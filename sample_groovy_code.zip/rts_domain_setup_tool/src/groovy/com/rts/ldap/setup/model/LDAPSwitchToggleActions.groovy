package com.rts.ldap.setup.model

class LDAPSwitchToggleActions {
	public static final SWITCH_TOGGLE_ACTION_ENABLE = "enable"
	public static final SWITCH_TOGGLE_ACTION_DISABLE = "disable"
}