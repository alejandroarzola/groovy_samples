package com.rts.ldap.setup.business

import com.rts.ldap.connection.LDAP

import com.rts.ldap.setup.model.*
import com.rts.ldap.setup.utils.RTSUtils



class LDAPSetupController {

	private static _ldapSetupController
	public static LDAPSetupController getInstance(){
		if(_ldapSetupController == null){
			_ldapSetupController = new LDAPSetupController()
		}
		_ldapSetupController
	}

	boolean createDomain(String domainName, LDAP ldapConnection){
		boolean result = false
		boolean domainRootIsCreated = false
		boolean appsStructureIsCreated = false
		boolean cmsFrameworkOrganizationalUnit = false
		boolean fileSystemOrganizationalUnitIsCreated = false
		boolean infoOrganizationalUnitIsCreated = false
		boolean memberShipAreaOrganizationalUnitIsCreated = false
		boolean orgChartOrganizationalUnit = false
		boolean peopleOrganizationalUnitIsCreated = false
		try{
			domainRootIsCreated = createDomainRoot(domainName,ldapConnection)
			if(domainRootIsCreated == true){
				appsStructureIsCreated = createAppsStructure(domainName, ldapConnection)
				if(appsStructureIsCreated == true){
					cmsFrameworkOrganizationalUnit = createCmsFrameworkOrganizationalUnit(domainName, ldapConnection)
					if(cmsFrameworkOrganizationalUnit == true){
						fileSystemOrganizationalUnitIsCreated = createFileSystemOrganizationalUnit(domainName, ldapConnection)
						if(fileSystemOrganizationalUnitIsCreated == true){
							infoOrganizationalUnitIsCreated = createInfoOrganizationalUnit(domainName,ldapConnection)
							if(infoOrganizationalUnitIsCreated == true){
								memberShipAreaOrganizationalUnitIsCreated = createMemberShipAreaOrganizationalUnit(domainName,ldapConnection)
								if(memberShipAreaOrganizationalUnitIsCreated == true){
									orgChartOrganizationalUnit = createOrgChartOrganizationalUnit(domainName, ldapConnection)
									if(orgChartOrganizationalUnit == true){
										peopleOrganizationalUnitIsCreated = createPeopleOrganizationalUnit(domainName, ldapConnection)
										if(peopleOrganizationalUnitIsCreated == true){
											result = true
										}
									}
								}
							}
						}
					}
				}
			}
		}catch(Exception ex){
			printException("createDomain", ex)
		}
		result
	}


	boolean createDomainRoot(String domainName, LDAP ldapConnection){
		boolean result = false
		try{
			result = createOrganizationalUnit(domainName, domainName, ldapConnection)
		}catch(Exception ex){
			printException("createDomainRoot",ex)
		}
		result
	}


	boolean createAppsStructure(String domainName, LDAP ldapConnection){
		boolean result = false
		String realContentPartialDn = "${LDAPCommonDistinguishedNames.REALCONTENT_RDN},${LDAPCommonDistinguishedNames.APPS_RDN}"
		String realFilePartialDn = "${LDAPCommonDistinguishedNames.REALFILE_RDN},${LDAPCommonDistinguishedNames.APPS_RDN}"
		String realProjectPartialDn = "${LDAPCommonDistinguishedNames.REALPROJECT_RDN},${LDAPCommonDistinguishedNames.APPS_RDN}"
		String realSecurityPartialDn = "${LDAPCommonDistinguishedNames.REALSECURITY_RDN},${LDAPCommonDistinguishedNames.APPS_RDN}"

		boolean appsStructureIsCreated = false
		boolean realContentPartialDnIsCreated = false
		boolean realFilePartialDnIsCreated = false
		boolean realProjectPartialDnIsCreated = false
		boolean realSecurityPartialDnIsCreated = false
		
		try{
			appsStructureIsCreated = createGenericGroupOfNames(LDAPCommonDistinguishedNames.APPS_RDN, domainName, ldapConnection)
			if(appsStructureIsCreated == true){
				realContentPartialDnIsCreated = createApplicationRolesStructure(realContentPartialDn, LDAPCommonDistinguishedNames.REALCONTENT_RDN, domainName,ldapConnection)
				if(realContentPartialDnIsCreated == true){					
					realFilePartialDnIsCreated = createApplicationRolesStructure(realFilePartialDn, LDAPCommonDistinguishedNames.REALFILE_RDN, domainName,ldapConnection)
					if(realFilePartialDnIsCreated == true){
						realProjectPartialDnIsCreated = createApplicationRolesStructure(realProjectPartialDn, LDAPCommonDistinguishedNames.REALPROJECT_RDN, domainName,ldapConnection)
						if(realProjectPartialDnIsCreated == true){
							realSecurityPartialDnIsCreated = createApplicationRolesStructure(realSecurityPartialDn, LDAPCommonDistinguishedNames.REALSECURITY_RDN, domainName,ldapConnection)
							if(realSecurityPartialDnIsCreated == true){
								result = true
							}
						}
						
					}
					
				}
			}
		}catch(Exception ex){
			printException("createAppsStructure",ex)
		}
		result
	}


	boolean createCmsFrameworkOrganizationalUnit(String domainName, LDAP ldapConnection){
		boolean result = false
		String cmsFrameworkRolesRdn = "${LDAPCommonDistinguishedNames.CMSFRAMEWORK_ROLES_NAME},${LDAPCommonDistinguishedNames.CMSFRAMEWORK_RDN}"
		String superAdminDn = "${LDAPCommonDistinguishedNames.SUPER_ADMIN_RDN},ou=${cmsFrameworkRolesRdn}"

		boolean cmsFrameworkOrganizationalUnitIsCreated = false
		boolean cmsFrameworkRolesRdnIsCreated = false
		boolean superAdminDnIsCreated = false
		
		try{
			cmsFrameworkOrganizationalUnitIsCreated = createOrganizationalUnit(LDAPCommonDistinguishedNames.CMSFRAMEWORK_NAME, domainName, ldapConnection)
			if(cmsFrameworkOrganizationalUnitIsCreated == true){
				cmsFrameworkRolesRdnIsCreated = createOrganizationalUnit(cmsFrameworkRolesRdn, domainName, ldapConnection)
				if(cmsFrameworkRolesRdnIsCreated == true){
					def cmsRole = [cmsRole: LDAPApplicationRoles.DOMAIN_ADMIN_ROLE_NAME]
					superAdminDnIsCreated = createBasicGroupOfNames(superAdminDn, LDAPCommonDistinguishedNames.SUPER_ADMIN_RDN, domainName,cmsRole, 'The Super Admin',null, ldapConnection)
					if(superAdminDnIsCreated == true){
						result = true
					}
				}
			}
		}catch(Exception ex){
			printException("createCmsFrameworkOrganizationalUnit",ex)
		}
		result
	}

	boolean createFileSystemOrganizationalUnit(String domainName, LDAP ldapConnection){
		boolean result = false
		String adminDn = "${LDAPCommonDistinguishedNames.ADMIN_RDN},${LDAPCommonDistinguishedNames.FILE_SYSTEM_RDN}"
		
		boolean fileSystemOrganizationalUnitIsCreated = false
		boolean adminDnIsCreated = false
		
		try{
			fileSystemOrganizationalUnitIsCreated = createOrganizationalUnit(LDAPCommonDistinguishedNames.FILE_SYSTEM_NAME,domainName,ldapConnection)
			if(fileSystemOrganizationalUnitIsCreated == true){
				adminDnIsCreated = createBasicGroupOfNames(adminDn,LDAPCommonDistinguishedNames.ADMIN_RDN,domainName, null,'The File System Admin',null, ldapConnection)
				if(adminDnIsCreated == true){
					result = true
				}
			}
		}catch(Exception ex){
			printException("createFileSystemOrganizationalUnit",ex)
		}
		result
	}

	boolean createInfoOrganizationalUnit(String domainName, LDAP ldapConnection){
		boolean result = false
		String infoDn = "${LDAPCommonDistinguishedNames.FILE_SYSTEM_RDN},${LDAPCommonDistinguishedNames.INFO_RDN}"
		def member = []
		String defaultUser = LDAPCommonMemberDistinguishedNames.MEMBER_UNKNOWN.replace('domainName',domainName)
		String domainMember = "ou=${domainName},${LDAPCommonDistinguishedNames.DOMAINS_RDN}"
		boolean infoOrganizationalUnitIsCreated = false
		boolean basicGroupOfNamesIsCreated = false
		try{

			member = [member: [defaultUser,domainMember]]
			infoOrganizationalUnitIsCreated = createOrganizationalUnit(LDAPCommonDistinguishedNames.INFO_NAME,domainName,ldapConnection)
			if(infoOrganizationalUnitIsCreated == true){
				basicGroupOfNamesIsCreated = createBasicGroupOfNames(infoDn,LDAPCommonDistinguishedNames.FILE_SYSTEM_NAME,domainName, null,'The orgchart list for FS',member, ldapConnection)
				if(basicGroupOfNamesIsCreated == true){
					result = true
				}
			}
		}catch(Exception ex){
			printException("createInfoOrganizationalUnit",ex)
		}
		result
	}

	boolean createMemberShipAreaOrganizationalUnit(String domainName, LDAP ldapConnection){
		boolean result = false
		String membershipDn = "${LDAPCommonDistinguishedNames.MEMBERSHIP_NAME},${LDAPCommonDistinguishedNames.MEMBERSHIP_AREA_RDN}"
		String peopleDn = "${LDAPCommonDistinguishedNames.PEOPLE_NAME},${LDAPCommonDistinguishedNames.MEMBERSHIP_AREA_RDN}"
		boolean memberShipAreaOrganizationalUnitIsCreated = false
		boolean membershipDnIsCreated = false
		boolean peopleDnIsCreated = false
		try{
			memberShipAreaOrganizationalUnitIsCreated = createOrganizationalUnit(LDAPCommonDistinguishedNames.MEMBERSHIP_AREA_NAME,domainName,ldapConnection)
			if(memberShipAreaOrganizationalUnitIsCreated == true){
				membershipDnIsCreated = createOrganizationalUnit(membershipDn,domainName,ldapConnection)
				if(membershipDnIsCreated == true){
					peopleDnIsCreated = createOrganizationalUnit(peopleDn,domainName,ldapConnection)
					if(peopleDnIsCreated == true){
						result = true
					}
				}
			}
		}catch(Exception ex){
			printException("createMemberShipAreaOrganizationalUnit",ex)
		}
		result
	}

	boolean createOrgChartOrganizationalUnit(String domainName, LDAP ldapConnection){
		boolean result = false
		String defaultUser = LDAPCommonMemberDistinguishedNames.MEMBER_UNKNOWN.replace('domainName',domainName)
		String orgChartDn = "${LDAPCommonDistinguishedNames.ORGCHART_ROOT_NODE_RDN},${LDAPCommonDistinguishedNames.ORGCHART_RDN}"
		def member = []
		boolean orgChartOrganizationalUnitIsCreated = false
		boolean basicGroupOfNamesIsCreated = false
		try{
			member = [member: defaultUser]
			orgChartOrganizationalUnitIsCreated = createOrganizationalUnit(LDAPCommonDistinguishedNames.ORGCHART_NAME,domainName,ldapConnection)
			if(orgChartOrganizationalUnitIsCreated == true){
				basicGroupOfNamesIsCreated = createBasicGroupOfNames(orgChartDn,LDAPCommonDistinguishedNames.ORGCHART_ROOT_NODE_NAME,domainName, null,'The orgchart root node',member, ldapConnection)
				if(basicGroupOfNamesIsCreated == true){
					result = true
				}
			}
		}catch(Exception ex){
			printException("createOrgChartOrganizationalUnit",ex)
		}
		result
	}
	
	boolean createPeopleOrganizationalUnit(String domainName, LDAP ldapConnection){
		boolean result = false
		String defaultUser = "${LDAPCommonMemberDistinguishedNames.MEMBER_UNKNOWN.replace('domainName',domainName)},${LDAPCommonDistinguishedNames.MAIN_DN}"
		String rtsAdmin = LDAPCommonMemberDistinguishedNames.MEMBER_RTS_ADMIN.replace('domainName',domainName)
		String admin2 = LDAPCommonMemberDistinguishedNames.MEMBER_ADMIN2.replace('domainName',domainName)
		
		boolean peopleOrganizationalUnitIsCreated = false
		boolean defaultUserIsCreated = false
		boolean rtsAdminIsCreated = false
		boolean admin2IsCreated = false
		try{
			peopleOrganizationalUnitIsCreated = createOrganizationalUnit(LDAPCommonDistinguishedNames.PEOPLE_NAME,domainName,LDAPObjectClasses.OBJECT_CLASS_PEOPLE_ATTRIBUTES, ldapConnection)
			if(peopleOrganizationalUnitIsCreated == true){
				defaultUserIsCreated = addPerson(defaultUser,"Unknown User","User","Unknown","unknown@${domainName}","uknown","",ldapConnection)
				if(defaultUserIsCreated == true){
					rtsAdminIsCreated = addPerson(rtsAdmin,"RTS Admin","Admin","RTS","admin@sks.com","rtsadmin","rtssks2011",ldapConnection)
					if(rtsAdminIsCreated == true){
						admin2IsCreated = addPerson(admin2,"Admin User","User","Admin","admin@${domainName}","admin2","admin",ldapConnection)
						if(admin2IsCreated == true){
							result = true
						}
					}
				}
			}
		}catch(Exception ex){
			printException("createPeopleOrganizationalUnit",ex)
		}
		result
	}
	
	
	
	boolean createApplicationRolesStructure(String applicationPartialDn, String applicationRdn, String domainName, LDAP ldapConnection){
		boolean result = false
		String domainAdminDn = "${LDAPCommonDistinguishedNames.DOMAIN_ADMIN_RDN},${applicationPartialDn}"
		String portalAdminDn = "${LDAPCommonDistinguishedNames.PORTAL_ADMIN_RDN},${applicationPartialDn}"
		String webAdminDn = "${LDAPCommonDistinguishedNames.WEB_ADMIN_RDN},${applicationPartialDn}"
		String updaterDn = "${LDAPCommonDistinguishedNames.UPDATER_RDN},${applicationPartialDn}"

		String defaultUser = LDAPCommonMemberDistinguishedNames.MEMBER_UNKNOWN.replace('domainName',domainName)
		String rtsAdmin = LDAPCommonMemberDistinguishedNames.MEMBER_RTS_ADMIN.replace('domainName',domainName)
		String admin2 = LDAPCommonMemberDistinguishedNames.MEMBER_ADMIN2.replace('domainName',domainName)

		def applicationRole = []
		def member = []
		String applicationRoleValue = ""

		boolean applicationPartialDnIsCreated = false
		boolean domainAdminDnIsCreated = false
		boolean portalAdminDnIsCreated = false
		boolean webAdminDnIsCreated = false
		boolean updaterDnIsCreated = false
		try{

			applicationPartialDnIsCreated = createGenericGroupOfNames(applicationPartialDn, domainName, ldapConnection)

			if(applicationPartialDnIsCreated == true){
				applicationRoleValue = "${getApplicationRolePrefix(applicationRdn)}:${LDAPApplicationRoles.DOMAIN_ADMIN_ROLE_NAME}"
				applicationRole = [appRole: applicationRoleValue]
				member = [member: [defaultUser,rtsAdmin,admin2]]
				domainAdminDnIsCreated = createApplicationGroupOfNames(domainAdminDn, LDAPCommonDistinguishedNames.DOMAIN_ADMIN_NAME, domainName, applicationRole, member, ldapConnection)

				if(domainAdminDnIsCreated == true){
					applicationRoleValue = "${getApplicationRolePrefix(applicationRdn)}:${LDAPApplicationRoles.PORTAL_ADMIN_ROLE_NAME}"
					applicationRole = [appRole: applicationRoleValue]
					member = [member : defaultUser]
					portalAdminDnIsCreated = createApplicationGroupOfNames(portalAdminDn, LDAPCommonDistinguishedNames.PORTAL_ADMIN_NAME, domainName, applicationRole, member, ldapConnection)

					if(portalAdminDnIsCreated == true){
						applicationRoleValue = "${getApplicationRolePrefix(applicationRdn)}:${LDAPApplicationRoles.WEB_ADMIN_ROLE_NAME}"
						applicationRole = [appRole: applicationRoleValue]
						webAdminDnIsCreated = createApplicationGroupOfNames(webAdminDn, LDAPCommonDistinguishedNames.WEB_ADMIN_NAME, domainName, applicationRole, member, ldapConnection)

						if(webAdminDnIsCreated){
							applicationRoleValue = "${getApplicationRolePrefix(applicationRdn)}:${LDAPApplicationRoles.UPDATER_ROLE_NAME}"
							applicationRole = [appRole: applicationRoleValue]
							updaterDnIsCreated = createApplicationGroupOfNames(updaterDn, LDAPCommonDistinguishedNames.UPDATER_NAME, domainName, applicationRole, member, ldapConnection)
							if(updaterDnIsCreated == true){
								result = true
							}
						}
					}
				}

			}
		}catch(Exception ex){
			printException("createApplicationRolesStructure",ex)
		}
		result
	}

	boolean createGenericGroupOfNames(String partialGroupDn, String domainName, LDAP ldapConnection){
		boolean result = false
		try{
			String fullPath = "${partialGroupDn},ou=${domainName},${LDAPCommonDistinguishedNames.DOMAINS_DN}"
			if(ldapConnection.exists(fullPath) == false){
				String groupGuid = RTSUtils.generateGUID()
				String defaultUser = LDAPCommonMemberDistinguishedNames.MEMBER_UNKNOWN.replace('domainName',domainName)
				def groupAttributes=[
							objectclass:LDAPObjectClasses.OBJECT_CLASS_GROUP_OF_NAMES_ATTRIBUTES,
							cn: LDAPCommonDistinguishedNames.APPS_NAME,
							member: defaultUser,
							addReferencesToGroup: LDAPBooleanValues.BOOLEAN_VALUE_TRUE,
							addSubgroupToGroup: LDAPBooleanValues.BOOLEAN_VALUE_TRUE,
							addUserToGroup: LDAPBooleanValues.BOOLEAN_VALUE_TRUE,
							appsPermissions: LDAPAttributeTypes.ATTRIBUTE_TYPE_APPS_PERMISSIONS_NAN,
							description: ' ',
							editSubgroup: LDAPBooleanValues.BOOLEAN_VALUE_TRUE,
							guid: groupGuid,
							moveGroup: LDAPBooleanValues.BOOLEAN_VALUE_TRUE,
							removeReferencesFromGroup: LDAPBooleanValues.BOOLEAN_VALUE_TRUE,
							removeSubgroupFromGroup: LDAPBooleanValues.BOOLEAN_VALUE_TRUE,
							removeUserFromGroup: LDAPBooleanValues.BOOLEAN_VALUE_TRUE
						]
	
				ldapConnection.add(fullPath,groupAttributes)
				result = true
			}	
			
		}catch(Exception ex){
			printException("createGenericGroupOfNames",ex)
		}
		result
		
	}


	boolean createApplicationGroupOfNames(String partialGroupDn, String commonName, String domainName, def applicationRole, def member, LDAP ldapConnection){
		boolean result = false
		try{

			String fullPath = "${partialGroupDn},ou=${domainName},${LDAPCommonDistinguishedNames.DOMAINS_DN}"
			if(ldapConnection.exists(fullPath) == false){
				String groupGuid = RTSUtils.generateGUID()

				def groupAttributes=[
							objectclass:LDAPObjectClasses.OBJECT_CLASS_GROUP_OF_NAMES_ATTRIBUTES,
							cn: commonName,
							addReferencesToGroup: LDAPBooleanValues.BOOLEAN_VALUE_TRUE,
							addSubgroupToGroup: LDAPBooleanValues.BOOLEAN_VALUE_TRUE,
							addUserToGroup: LDAPBooleanValues.BOOLEAN_VALUE_TRUE,
							appsPermissions: LDAPAttributeTypes.ATTRIBUTE_TYPE_APPS_PERMISSIONS_NAN,
							description: ' ',
							editSubgroup: LDAPBooleanValues.BOOLEAN_VALUE_TRUE,
							guid: groupGuid,
							moveGroup: LDAPBooleanValues.BOOLEAN_VALUE_TRUE,
							removeReferencesFromGroup: LDAPBooleanValues.BOOLEAN_VALUE_TRUE,
							removeSubgroupFromGroup: LDAPBooleanValues.BOOLEAN_VALUE_TRUE,
							removeUserFromGroup: LDAPBooleanValues.BOOLEAN_VALUE_TRUE
						]
				groupAttributes.putAll(applicationRole)
				groupAttributes.putAll(member)

				ldapConnection.add(fullPath,groupAttributes)
				result = true

			}

		}catch(Exception ex){
			printException("createApplicationGroupOfNames",ex)
		}
		result
	}

	boolean createBasicGroupOfNames(String partialGroupDn, String commonName, String domainName, def applicationRole, String description,def groupMember, LDAP ldapConnection){
		boolean result = false
		try{
			String fullPath = "${partialGroupDn},ou=${domainName},${LDAPCommonDistinguishedNames.DOMAINS_DN}"
			if(ldapConnection.exists(fullPath) == false){
				
				String defaultUser = LDAPCommonMemberDistinguishedNames.MEMBER_UNKNOWN.replace('domainName',domainName)
				String rtsAdmin = LDAPCommonMemberDistinguishedNames.MEMBER_RTS_ADMIN.replace('domainName',domainName)
				String admin2 = LDAPCommonMemberDistinguishedNames.MEMBER_ADMIN2.replace('domainName',domainName)
	
				String groupGuid = RTSUtils.generateGUID()
	
				def groupAttributes=[
							objectclass:LDAPObjectClasses.OBJECT_CLASS_GROUP_OF_NAMES_ATTRIBUTES,
							cn: commonName,
							description: description,
							guid: groupGuid,
	
						]
	
				if(applicationRole != null){
					groupAttributes.putAll(applicationRole)
				}
				if(groupMember == null){
					groupAttributes.putAll([member: [defaultUser,rtsAdmin,admin2]])
				}else{
					groupAttributes.putAll(groupMember)
				}
	
				ldapConnection.add(fullPath,groupAttributes)
				result = true
			}
		}catch(Exception ex){
			printException("createBasicGroupOfNames",ex)
		}
		result
	}



	boolean createOrganizationalUnit(String organizationalUnitNameDn, String domainName,LDAP ldapConnection){
		boolean result = false
		try{
			String fullPath = ""
			if(organizationalUnitNameDn == domainName){
				fullPath = "ou=${domainName},${LDAPCommonDistinguishedNames.DOMAINS_DN}"
			}else{
				fullPath = "ou=${organizationalUnitNameDn},ou=${domainName},${LDAPCommonDistinguishedNames.DOMAINS_DN}"
			}
			if(ldapConnection.exists(fullPath) == false){
				String domainGuid = RTSUtils.generateGUID()
				def newDomain=[
							objectclass:LDAPObjectClasses.OBJECT_CLASS_ORGANIZAIONAL_UNIT_ATTRIBUTES,
							guid: domainGuid
						]
				ldapConnection.add(fullPath,newDomain)
				result = true
			}
		}catch(Exception ex){
			printException("createOrganizationalUnit",ex)
		}
		result
	}
	
	boolean createOrganizationalUnit(String organizationalUnitNameDn, String domainName,def customObjectClass,LDAP ldapConnection){
		boolean result = false
		try{
			String fullPath = ""
			if(organizationalUnitNameDn == domainName){
				fullPath = "ou=${domainName},${LDAPCommonDistinguishedNames.DOMAINS_DN}"
			}else{
				fullPath = "ou=${organizationalUnitNameDn},ou=${domainName},${LDAPCommonDistinguishedNames.DOMAINS_DN}"
			}
			if(ldapConnection.exists(fullPath) == false){
				String domainGuid = RTSUtils.generateGUID()
				def newDomain=[
							guid: domainGuid
						]

				if(customObjectClass == null){
					newDomain.putAll([objectclass:LDAPObjectClasses.OBJECT_CLASS_ORGANIZAIONAL_UNIT_ATTRIBUTES])
				}else{
					newDomain.putAll([objectclass: customObjectClass])
				}
				ldapConnection.add(fullPath,newDomain)
				result = true
			}
		}catch(Exception ex){
			printException("createOrganizationalUnit",ex)
		}
		result
	}

	boolean addPerson(String personDn, String commonName, String surName, String givenName, String mail, String uid, String userPassword,LDAP ldapConnection){
		boolean result = false
		try{
			if(ldapConnection.exists(personDn) == false){
				String personGuid = RTSUtils.generateGUID()
				String encryptedPassword = RTSUtils.getInstance().encryptMD5Password(userPassword)
				def personAttributes=[
							objectclass: LDAPObjectClasses.OBJECT_CLASS_FULL_PERSON_ATTRIBUTES,
							cn: commonName,
							sn: surName,
							givenName: givenName,
							guid: personGuid,
							mail: mail,
							uid: uid
						]
				if(uid != "unknown"){
					personAttributes.putAll([loginAllowed: LDAPBooleanValues.BOOLEAN_VALUE_TRUE])
					personAttributes.putAll([userPassword: encryptedPassword])
				}

				ldapConnection.add(personDn,personAttributes)
				result = true
			}
		}catch(Exception ex){
			printException("addPerson",ex)
		}
		result
	}
	
	String getApplicationRolePrefix(String applicationRdn){
		String result = ""
		switch(applicationRdn){
			case LDAPCommonDistinguishedNames.REALCONTENT_RDN:
				result = LDAPApplicationRoles.CMS_PREFIX
				break
			case LDAPCommonDistinguishedNames.REALFILE_RDN:
				result = LDAPApplicationRoles.REALFILE_PREFIX
				break
			case LDAPCommonDistinguishedNames.REALPROJECT_RDN:
				result = LDAPApplicationRoles.REALPROJECT_PREFIX
				break
			case LDAPCommonDistinguishedNames.REALSECURITY_RDN:
				result = LDAPApplicationRoles.REALSECURITY_PREFIX
				break

		}
		result
	}
	
	boolean domainExists(String domainName, LDAP ldapConnection){
		boolean result = false
		String fullPath = "ou=${domainName},${LDAPCommonDistinguishedNames.DOMAINS_DN}"
		try{
			result = ldapConnection.exists(fullPath)
		}catch(Exception ex){
			printException("domainExists",ex)
		}
		result
	}
	
	void printException(String methodName, Exception ex){
		println "Exception in ${this.class}.${methodName}: ${ex.getMessage()}"
		ex.printStackTrace()
	}
}
