package com.rts.ldap.setup.model
/**
 * @author alex
 */
class LDAPAttributeTypes {
	 public static String ATTRIBUTE_TYPE_ISADMIN_GROUP = "isAdmin"
	 public static String ATTRIBUTE_TYPE_REFERENCE_GROUP ="referenceGroup"
	 public static String ATTRIBUTE_TYPE_REFERENCE_GROUP_PROPAGATED ="referenceGroupPropagated"
	 public static String ATTRIBUTE_TYPE_LOGIN_ALLOWED = "loginAllowed"
	 public static String ATTRIBUTE_TYPE_SYSTEM_LOCKED = "systemLocked"
	 public static String ATTRIBUTE_TYPE_LOCKED = "locked"
	 public static String ATTRIBUTE_TYPE_APPS_PERMISSIONS = "appsPermissions"
	 public static String ATTRIBUTE_TYPE_APPS_PERMISSIONS_NAN = "NaN"
	 public static String ATTRIBUTE_TYPE_ADD_REFERENCES_TO_GROUP = "addReferencesToGroup"
	 public static String ATTRIBUTE_TYPE_ADD_SUBGROUP_TO_GROUP = "addSubGroupToGroup"
	 public static String ATTRIBUTE_TYPE_ADD_USER_TO_GROUP = "addUserToGroup"
	 public static String ATTRIBUTE_TYPE_EDIT_SUBGROUP = "editSubgroup"
	 public static String ATTRIBUTE_TYPE_MOVE_GROUP = "moveGroup"
	 public static String ATTRIBUTE_REMOVE_REFERENCES_FROM_GROUP = "removeReferencesFromGroup"
	 public static String ATTRIBUTE_REMOVE_SUBGROUP_FROM_GROUP = "removeSubgroupFromGroup"
	 public static String ATTRIBUTE_REMOVE_USER_FROM_GROUP = "removeUserFromGroup"
	 
}
