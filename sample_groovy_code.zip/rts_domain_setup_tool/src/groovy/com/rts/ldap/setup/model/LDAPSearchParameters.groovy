package com.rts.ldap.setup.model
/**
 * @author alex
 */
class LDAPSearchParameters {
	static final String PARAMETER_ORGANIZATIONAL_UNIT_NAME = "ou"
	static final String PARAMETER_DISTINGUISHED_NAME = "dn"
	static final String PARAMETER_COMMON_NAME = "cn"
	static final String PARAMETER_APPS_PERMISSIONS = "appsPermissions"
	static final String PARAMETER_DESCRIPTION = "description"
	static final String	PARAMETER_UID ="uid"
	static final String	PARAMETER_GUID ="guid"
	static final String	PARAMETER_MAIL ="mail"
}
