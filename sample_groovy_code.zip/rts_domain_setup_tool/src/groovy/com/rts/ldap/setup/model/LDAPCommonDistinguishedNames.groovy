package com.rts.ldap.setup.model
/**
 * 
 * @author alex
 *
 */
class LDAPCommonDistinguishedNames {

	public final static  String MAIN_DN = "dc=realtimesites,dc=com"
	public final static  String APPS_DN = "ou=apps,"+ MAIN_DN
	public final static  String APPS_NAME = "Apps"
	public final static  String APPS_RDN = "ou=${APPS_NAME}"
	public final static  String DOMAINS_DN = "${DOMAINS_RDN},${MAIN_DN}" 
	public final static  String DOMAINS_RDN = "ou=domains"
	public final static  String DOMAIN_APP_RDN = "ou=apps"
	public final static  String CMSFRAMEWORK_NAME = "cmsframework"
	public final static  String CMSFRAMEWORK_RDN = "ou=${CMSFRAMEWORK_NAME}"
	public final static  String REALCONTENT_RDN = "ou=realContent"
	public final static  String CMSFRAMEWORK_ROLES_NAME = "roles"
	public final static  String CMSFRAMEWORK_ROLES_DN = "ou=${CMSFRAMEWORK_ROLES_NAME},${CMSFRAMEWORK_RDN}"
	public final static  String CMSFRAMEWORK_SUPER_ADMIN = "ou=Super Admin"
	
	public final static  String ORGCHART_NAME = "orgChart"
	public final static  String ORGCHART_RDN = "ou=${ORGCHART_NAME}"
	
	public final static  String PEOPLE_NAME = "people"
	public final static  String PEOPLE_RDN = "ou=${PEOPLE_NAME}"
	
	public final static  String FILE_SYSTEM_NAME = "FS"
	public final static  String FILE_SYSTEM_RDN = "ou=${FILE_SYSTEM_NAME}"
	
	public final static  String INFO_NAME = "info"
	public final static  String INFO_RDN = "ou=${INFO_NAME}"
	
	public final static  String MEMBERSHIP_AREA_NAME = "membership area"
	public final static  String MEMBERSHIP_AREA_RDN = "ou=${MEMBERSHIP_AREA_NAME}"
	
	public final static  String MEMBERSHIP_NAME = "membership"
	public final static  String MEMBERSHIP_RDN = "ou=${MEMBERSHIP_NAME}"
	
	public final static  String REALFILE_RDN = "ou=realFile"
	public final static  String FILE_INFO_RDN = "ou=info"
	public final static  String REALTASK_RDN = "ou=realtask"
	public final static  String REALPROJECT_RDN = "ou=realProject"
	public final static  String REALSECURITY_RDN = "ou=realSecurity"
	public final static  String DEFAULTUSER_RDN = "uid=unknown"
	
	
	public final static  String ADMIN_NAME = "Admin"
	public final static  String SUPER_ADMIN_NAME = "Super Admin"
	public final static  String DOMAIN_ADMIN_NAME = "Domain Admin"
	public final static  String PORTAL_ADMIN_NAME = "Portal Admin"
	public final static  String WEB_ADMIN_NAME = "Web Admin"
	public final static  String UPDATER_NAME = "Updater"
	
	
	public final static  String SUPER_ADMIN_RDN = "ou=${SUPER_ADMIN_NAME}"
	public final static  String DOMAIN_ADMIN_RDN = "ou=${DOMAIN_ADMIN_NAME}"
	public final static  String PORTAL_ADMIN_RDN = "ou=${PORTAL_ADMIN_NAME}"
	public final static  String WEB_ADMIN_RDN = "ou=${WEB_ADMIN_NAME}"
	public final static  String UPDATER_RDN = "ou=${UPDATER_NAME}"
	public final static  String ADMIN_RDN = "ou=${ADMIN_NAME}"
	
	public final static  String ORGCHART_ROOT_NODE_NAME = "root"
	public final static  String ORGCHART_ROOT_NODE_RDN = "ou=${ORGCHART_ROOT_NODE_NAME}"
}
